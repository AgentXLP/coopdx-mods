const struct Animation *const mario_anims[] = {
    anim_CD,
};
