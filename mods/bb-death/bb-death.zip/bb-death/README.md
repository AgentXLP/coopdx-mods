# Breaking Bad Death Cutscene

This mod replaces the normal death sequence with the final shot of Breaking Bad where the camera pans away from Walter White's body. Bubbling is automatically disabled and the sequence is only triggered by dying standing, on your back, on your stomach, suffocating, being electrocuted or drowning.

When a player dies, the music will play and get louder the closer you are to the body and quieter the farther away. The vanilla music also fades out the closer you are to the body.

Press A or B to skip the cutscene.

Run /bb-gameover to toggle the death cutscene only playing if you have 0 lives left.