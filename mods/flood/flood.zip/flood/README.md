# Flood

<a href="http://www.youtube.com/watch?feature=player_embedded&v=1iPTLlM9Hmg" target="_blank">
 <img src="http://img.youtube.com/vi/1iPTLlM9Hmg/mqdefault.jpg" alt="Watch the video" width="640" height="360" border="10" />
</a>

This mod adds a flood escape gamemode to sm64ex-coop, you must escape the flood and reach the top of the level before everything is flooded.

Special thanks to Mr.Needlemouse64 and Blocky for their respective easter eggs.