# Weather Cycle DX

This mod adds a weather cycle system with cloudy skies, rain, and storms to sm64coopdx. It uses Day Night Cycle DX as a base library, meaning you need to have it enabled in order to use this mod. There is also a toggleable Aurora Borealis that starts after midnight. I've worked on this mod for months now and managed to optimize the storm to run at 200-300 microseconds, which is an impressive number especially compared to the earlier 6000 microseconds.


Special thanks to Floralys for the original concept.

Special thanks to eros71 for saving the mod!