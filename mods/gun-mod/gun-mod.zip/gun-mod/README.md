# Grand Theft Mario - guns in sm64ex-coop

https://youtu.be/3bQfwIefI2I

<img width="600" alt="gunmod1" src="https://user-images.githubusercontent.com/44549182/182983983-aa7616e9-2071-4d8d-bd34-a75d420978f3.png">
<img width="600" alt="gunmod4" src="https://user-images.githubusercontent.com/44549182/182983994-e8f36db3-ddeb-4d45-8910-9f2ba8fbfc6a.png">

This mod adds guns to sm64ex-coop. You will automatically obtain a gun and shoot it by pressing Y. Swap between the pistol and the magnum with DPad Up.