# Left 4 Dead 2 HUD

https://user-images.githubusercontent.com/44549182/189468165-475396e2-124b-46c9-b834-6a630a7b57e1.mp4

This mod adds the Left 4 Dead 2 HUD into sm64ex-coop with other players' health bars on the side too, you can cycle through them with DPad left and DPad right. This mod is fully cross compatible and fully integrated with Downing as well so players will show as incapacitated on their healthbars and everything else.

If SM64 health is off (by default it is) you can pick up 1 ups and use them as first aid kits to heal.