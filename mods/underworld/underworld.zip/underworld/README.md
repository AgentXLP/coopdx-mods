# Super Mario 64: The Underworld

<a href="http://www.youtube.com/watch?feature=player_embedded&v=2gF2SVSHCMI" target="_blank">
 <img src="http://img.youtube.com/vi/2gF2SVSHCMI/mqdefault.jpg" alt="Watch the video" width="640" height="360" border="10" />
</a>

Mario is pulled into another land some call The Underworld...
He must make his way through this condemned land and help in both the escape of himself and someone he thinks he can trust from the Underworld...
This is a 30 star romhack with a fully custom cutscene system, dialog system and boss fight entirely in Lua created for the sm64ex-coop level competition.

Special thanks to Squishy for the compass textures
